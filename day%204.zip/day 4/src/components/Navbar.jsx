import {useSelector} from 'react-redux';
export default ()=> <nav>Cart: {useSelector(s=>s.cart.items.length)}</nav>;