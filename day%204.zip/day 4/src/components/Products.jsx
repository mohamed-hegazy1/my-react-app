import {useDispatch} from 'react-redux';import {addItem} from '../redux/slices/cartSlice';
const p={id:1,name:'Phone'};
export default ()=>{const d=useDispatch();return <button onClick={()=>d(addItem(p))}>Add Phone</button>}