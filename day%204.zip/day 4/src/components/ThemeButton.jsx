import {useTheme} from '../context/ThemeContext';
export default ()=>{const {theme,toggleTheme}=useTheme();return <button onClick={toggleTheme}>{theme}</button>}