# ReactJS Assignment 2 - Solution

This version satisfies the assignment requirements:
- useState
- useEffect
- Custom Hook: useFetch
- Inline Styling
- CSS Stylesheet
- CSS Modules
- Styled Components
- Bootstrap / React-Bootstrap
- Responsive layout
- Organized components/hooks/styles
- Functional product fetching and search

## Run
npm install
npm run dev
