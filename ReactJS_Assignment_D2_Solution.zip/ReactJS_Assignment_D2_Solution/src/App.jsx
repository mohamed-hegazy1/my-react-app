import Navbar from "./components/Navbar";
import ProductList from "./components/ProductList";
import "./App.css";

function App() {
  return (
    <div className="app">
      <Navbar />
      <main>
        <ProductList />
      </main>

      <footer className="bg-dark text-white text-center py-4 mt-5">
        <p className="mb-0">© 2026 Store Hegazy - ReactJS Assignment 2</p>
      </footer>
    </div>
  );
}

export default App;
