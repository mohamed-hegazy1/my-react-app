import { useState } from "react";
import styles from "../styles/ProductCard.module.css";
import { Card, Button, Badge } from "react-bootstrap";
import styled from "styled-components";

const Price = styled.p`
  color: #198754;
  font-size: 1.4rem;
  font-weight: 700;
  margin-bottom: 8px;
`;

function ProductCard({ product }) {
  const [showDetails, setShowDetails] = useState(false);

  // Inline Styling requirement
  const titleStyle = {
    fontSize: "1.15rem",
    fontWeight: "700",
    minHeight: "45px",
  };

  return (
    <Card className={`${styles.card} h-100 shadow-sm`}>
      <Card.Img
        variant="top"
        src={product.image}
        alt={product.title}
        className={styles.image}
      />

      <Card.Body className="d-flex flex-column">
        <Card.Title style={titleStyle}>{product.title}</Card.Title>

        <Card.Text className={styles.category}>
          {product.category}
        </Card.Text>

        {/* Styled Components requirement */}
        <Price>${product.price}</Price>

        <Card.Text>⭐ {product.rating}</Card.Text>

        <div className="mb-3">
          {product.inStock ? (
            <Badge bg="success">In Stock</Badge>
          ) : (
            <Badge bg="danger">Out of Stock</Badge>
          )}
        </div>

        <div className="mt-auto">
          <Button
            variant="dark"
            className="me-2"
            onClick={() => setShowDetails(!showDetails)}
          >
            {showDetails ? "Hide Details" : "Show Details"}
          </Button>

          {product.inStock && (
            <Button variant="success">Buy Now</Button>
          )}
        </div>

        {showDetails && (
          <div className={styles.details}>
            {product.description}
          </div>
        )}
      </Card.Body>
    </Card>
  );
}

export default ProductCard;
