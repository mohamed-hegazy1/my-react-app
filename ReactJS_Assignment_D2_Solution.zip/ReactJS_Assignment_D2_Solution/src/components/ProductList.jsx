import { useEffect, useState } from "react";
import ProductCard from "./ProductCard";
import useFetch from "../hooks/useFetch";
import styles from "../styles/ProductList.module.css";

function ProductList() {
  const [search, setSearch] = useState("");
  const { data: apiProducts, loading, error } = useFetch(
    "https://dummyjson.com/products?limit=12"
  );

  // Keep the previous project data shape while using a real API.
  const products = (apiProducts?.products || []).map((product) => ({
    id: product.id,
    title: product.title,
    price: product.price,
    category: product.category,
    rating: product.rating,
    inStock: product.stock > 0,
    image: product.thumbnail,
    description: product.description,
  }));

  useEffect(() => {
    document.title = `Store Hegazy (${products.length} products)`;
  }, [products.length]);

  const filteredProducts = products.filter((product) =>
    product.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <section id="products" className={`${styles.section} container py-5`}>
      <div className="text-center mb-4">
        <h1 className="fw-bold">Our Products</h1>
        <p className="text-muted">
          Discover our latest products
        </p>
      </div>

      <div className="row justify-content-center mb-4">
        <div className="col-12 col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {loading && (
        <div className="text-center py-5">
          <div className="spinner-border text-success" role="status" />
          <p className="mt-2">Loading products...</p>
        </div>
      )}

      {error && (
        <div className="alert alert-danger text-center">
          {error}
        </div>
      )}

      {!loading && !error && (
        <div className="row g-4">
          {filteredProducts.map((product) => (
            <div className="col-12 col-sm-6 col-lg-4" key={product.id}>
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      )}

      {!loading && !error && filteredProducts.length === 0 && (
        <p className="text-center text-muted">No products found.</p>
      )}
    </section>
  );
}

export default ProductList;
