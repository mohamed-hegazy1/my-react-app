import "bootstrap/dist/css/bootstrap.min.css";

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-3 px-md-5">
      <div className="container-fluid">
        <a className="navbar-brand fw-bold" href="#home">
          Store Hegazy
        </a>

        <div className="navbar-nav ms-auto flex-row gap-3">
          <a className="nav-link" href="#home">Home</a>
          <a className="nav-link" href="#products">Products</a>
          <a className="nav-link" href="#about">About</a>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
