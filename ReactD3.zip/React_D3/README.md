# ReactJS Assignment 3 Solution

Implemented from the assignment requirements:
- Multiple pages
- React Router DOM
- Home, About, Contact/Register
- Navigation Bar
- Controlled React form with state
- 5 input fields
- Validation
- Success message
- 404 Not Found route
- Separate Components and Pages

Run:
npm install
npm run dev
