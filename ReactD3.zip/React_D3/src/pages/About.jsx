function About() {
  return (
    <section className="content-card">
      <p className="eyebrow">About Page</p>
      <h1>About Store Hegazy</h1>
      <p>
        Store Hegazy is a simple ReactJS application created for Assignment 3.
        It demonstrates multiple pages, navigation using React Router DOM,
        and a controlled registration/contact form.
      </p>
      <div className="features">
        <div className="feature">
          <h3>React Router</h3>
          <p>Move between Home, About, and Contact without refreshing the page.</p>
        </div>
        <div className="feature">
          <h3>React State</h3>
          <p>Form inputs are controlled using React state.</p>
        </div>
        <div className="feature">
          <h3>Validation</h3>
          <p>Required fields and valid email, phone, and password values are checked.</p>
        </div>
      </div>
    </section>
  );
}

export default About;