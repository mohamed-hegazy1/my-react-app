import { useState } from "react";

const initialForm = {
  fullName: "",
  email: "",
  password: "",
  phone: "",
  message: ""
};

function Contact() {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState("");

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setSuccess("");
    setErrors((prev) => ({ ...prev, [name]: "" }));
  }

  function validate() {
    const e = {};
    if (!formData.fullName.trim()) e.fullName = "Full Name is required.";
    else if (formData.fullName.trim().length < 3)
      e.fullName = "Full Name must be at least 3 characters.";

    if (!formData.email.trim()) e.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      e.email = "Enter a valid email address.";

    if (!formData.password) e.password = "Password is required.";
    else if (formData.password.length < 6)
      e.password = "Password must be at least 6 characters.";

    if (!formData.phone.trim()) e.phone = "Phone Number is required.";
    else if (!/^[0-9+\s-]{8,15}$/.test(formData.phone))
      e.phone = "Enter a valid phone number.";

    if (!formData.message.trim()) e.message = "Message is required.";
    else if (formData.message.trim().length < 10)
      e.message = "Message must be at least 10 characters.";

    return e;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSuccess("Registration submitted successfully!");
      setFormData(initialForm);
    }
  }

  return (
    <section className="form-section">
      <div className="form-card">
        <p className="eyebrow">Contact / Registration</p>
        <h1>Register With Us</h1>
        <p className="form-description">
          Fill in the form below. The page will not refresh when you submit it.
        </p>

        {success && <div className="success-message">✓ {success}</div>}

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label htmlFor="fullName">Full Name</label>
            <input id="fullName" name="fullName" type="text"
              value={formData.fullName} onChange={handleChange}
              placeholder="Enter your full name" />
            {errors.fullName && <small>{errors.fullName}</small>}
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input id="email" name="email" type="email"
              value={formData.email} onChange={handleChange}
              placeholder="example@email.com" />
            {errors.email && <small>{errors.email}</small>}
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input id="password" name="password" type="password"
              value={formData.password} onChange={handleChange}
              placeholder="At least 6 characters" />
            {errors.password && <small>{errors.password}</small>}
          </div>

          <div className="form-group">
            <label htmlFor="phone">Phone Number</label>
            <input id="phone" name="phone" type="tel"
              value={formData.phone} onChange={handleChange}
              placeholder="+20 100 000 0000" />
            {errors.phone && <small>{errors.phone}</small>}
          </div>

          <div className="form-group">
            <label htmlFor="message">Message / Address</label>
            <textarea id="message" name="message" rows="4"
              value={formData.message} onChange={handleChange}
              placeholder="Enter your message or address" />
            {errors.message && <small>{errors.message}</small>}
          </div>

          <button type="submit" className="btn primary submit-btn">
            Submit Form
          </button>
        </form>
      </div>
    </section>
  );
}

export default Contact;