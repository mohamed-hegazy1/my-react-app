import { Link } from "react-router-dom";

function Home() {
  return (
    <section className="hero">
      <div className="hero-card">
        <p className="eyebrow">ReactJS Assignment 3</p>
        <h1>Welcome to Store Hegazy</h1>
        <p>
          This project demonstrates React Router navigation and a controlled
          React form with validation.
        </p>
        <div className="button-group">
          <Link to="/about" className="btn primary">About Us</Link>
          <Link to="/contact" className="btn secondary">Contact / Register</Link>
        </div>
      </div>
    </section>
  );
}

export default Home;